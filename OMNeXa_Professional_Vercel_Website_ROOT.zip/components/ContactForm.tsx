"use client";

import { useMemo, useState } from "react";
import { services, topmateUrl } from "@/lib/site-data";

type FormState = {
  name: string;
  email: string;
  phone: string;
  organisation: string;
  service: string;
  message: string;
};

const initialState: FormState = {
  name: "",
  email: "",
  phone: "",
  organisation: "",
  service: "",
  message: ""
};

export default function ContactForm({ initialService = "" }: { initialService?: string }) {
  const [form, setForm] = useState<FormState>({ ...initialState, service: initialService });
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle");
  const [statusText, setStatusText] = useState("");

  const selectedServiceLabel = useMemo(() => {
    return services.find((service) => service.slug === form.service)?.title || "General enquiry";
  }, [form.service]);

  function updateField(name: keyof FormState, value: string) {
    setForm((current) => ({ ...current, [name]: value }));
  }

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setStatus("loading");
    setStatusText("Sending your enquiry...");

    try {
      const response = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, serviceLabel: selectedServiceLabel })
      });
      const result = await response.json();

      if (!response.ok) {
        throw new Error(result?.message || "Unable to send enquiry.");
      }

      setStatus("success");
      setStatusText("Thank you. Your enquiry has been sent to OMNeXa.");
      setForm({ ...initialState, service: initialService });
    } catch (error) {
      setStatus("error");
      setStatusText(error instanceof Error ? error.message : "Something went wrong. Please email directly.");
    }
  }

  return (
    <div className="contact-card">
      <div>
        <p className="eyebrow">Start a conversation</p>
        <h2>Tell us what you want to build, solve or transform.</h2>
        <p className="muted">
          Use the form below for advisory, speaking, workshops, mentoring or collaboration enquiries. You can also book a direct conversation through Topmate.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="contact-form">
        <div className="form-grid two">
          <label>
            Name
            <input
              required
              value={form.name}
              onChange={(event) => updateField("name", event.target.value)}
              placeholder="Your full name"
            />
          </label>
          <label>
            Email
            <input
              required
              type="email"
              value={form.email}
              onChange={(event) => updateField("email", event.target.value)}
              placeholder="name@company.com"
            />
          </label>
        </div>

        <div className="form-grid two">
          <label>
            Contact number
            <input
              value={form.phone}
              onChange={(event) => updateField("phone", event.target.value)}
              placeholder="+65 ..."
            />
          </label>
          <label>
            Organisation
            <input
              value={form.organisation}
              onChange={(event) => updateField("organisation", event.target.value)}
              placeholder="Company / school / institution"
            />
          </label>
        </div>

        <label>
          Service interest
          <select value={form.service} onChange={(event) => updateField("service", event.target.value)}>
            <option value="">General enquiry</option>
            {services.map((service) => (
              <option key={service.slug} value={service.slug}>
                {service.title}
              </option>
            ))}
          </select>
        </label>

        <label>
          Message
          <textarea
            required
            rows={5}
            value={form.message}
            onChange={(event) => updateField("message", event.target.value)}
            placeholder="Briefly describe your requirement, timeline, audience and expected outcome."
          />
        </label>

        <div className="form-actions">
          <button type="submit" className="button primary" disabled={status === "loading"}>
            {status === "loading" ? "Sending..." : "Send enquiry"}
          </button>
          <a className="button secondary" href={topmateUrl} target="_blank" rel="noreferrer">
            Book on Topmate
          </a>
        </div>
        {statusText && <p className={`form-status ${status}`}>{statusText}</p>}
      </form>
    </div>
  );
}
