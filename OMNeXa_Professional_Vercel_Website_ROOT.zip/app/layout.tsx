import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "OMNeXa | Where Consciousness Meets Intelligence",
  description:
    "OMNeXa is a Singapore-based consultancy preparing people and organizations for an AI-enabled, sustainability-aligned and human-centered future.",
  openGraph: {
    title: "OMNeXa | Where Consciousness Meets Intelligence",
    description:
      "Career and education pathways, risk and compliance advisory, ESG transformation, responsible AI, robotics and conscious leadership.",
    images: ["/brand/omnexa-logo-hero.webp"]
  }
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
