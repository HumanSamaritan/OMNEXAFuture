import ContactForm from "@/components/ContactForm";
import { engagementFormats, faqs, navItems, services, testimonials, topmateUrl } from "@/lib/site-data";

function ServiceCard({ service }: { service: (typeof services)[number] }) {
  return (
    <article className="service-card" id={service.slug}>
      <div className="service-image" style={{ backgroundImage: `url(${service.image})` }} />
      <div className="service-body">
        <div className="service-icon">{service.icon}</div>
        <h3>{service.title}</h3>
        <p>{service.short}</p>
        <div className="tag-row">
          {service.formats.slice(0, 3).map((format) => (
            <span key={format}>{format}</span>
          ))}
        </div>
        <div className="card-actions">
          <a href={`/services/${service.slug}`} className="text-link">
            View service →
          </a>
          <a href={`/services/${service.slug}#contact`} className="mini-button">
            Apply / enquire
          </a>
        </div>
      </div>
    </article>
  );
}

export default function Home() {
  return (
    <main>
      <header className="site-header">
        <a href="#top" className="brand">
          <img src="/brand/omnexa-mark.webp" alt="OMNeXa logo" />
          <span>
            <strong>OMNeXa</strong>
            <small>Where Consciousness Meets Intelligence</small>
          </span>
        </a>
        <nav>
          {navItems.map((item) => (
            <a key={item.href} href={item.href}>
              {item.label}
            </a>
          ))}
        </nav>
        <a className="button header-cta" href="#contact">
          Apply / Enquire
        </a>
      </header>

      <section id="top" className="hero section-shell">
        <div className="hero-copy">
          <p className="eyebrow">Singapore-based advisory • AI-era readiness • Human-centered transformation</p>
          <h1>Build future-ready people, institutions and ecosystems.</h1>
          <p className="hero-text">
            OMNeXa bridges compliance, sustainability, AI adoption, education pathways and emotional well-being — designed for practical execution, not only inspiration.
          </p>
          <div className="hero-actions">
            <a className="button primary" href="#services">
              Explore services
            </a>
            <a className="button secondary" href={topmateUrl} target="_blank" rel="noreferrer">
              Book on Topmate
            </a>
          </div>
          <div className="hero-stats">
            <div>
              <strong>20+</strong>
              <span>Years in AML/KYC, sanctions and controls</span>
            </div>
            <div>
              <strong>6</strong>
              <span>Integrated pillars for future readiness</span>
            </div>
            <div>
              <strong>APAC + EMEA</strong>
              <span>Regional and global execution exposure</span>
            </div>
          </div>
        </div>
        <div className="hero-visual">
          <img src="/brand/omnexa-logo-hero.webp" alt="OMNeXa logo visual" />
          <div className="floating-card top">
            <strong>Risk + ESG + AI + Human Growth</strong>
            <span>One integrated operating lens</span>
          </div>
          <div className="floating-card bottom">
            <strong>Human values. Responsible intelligence.</strong>
            <span>Measurable execution.</span>
          </div>
        </div>
      </section>

      <section className="trust-strip">
        <span>For corporates</span>
        <span>Financial institutions</span>
        <span>Schools & universities</span>
        <span>Technology partners</span>
        <span>Foundations & public bodies</span>
      </section>

      <section className="section-shell convergence">
        <div className="section-heading compact">
          <p className="eyebrow">Why OMNeXa</p>
          <h2>The ecosystem is converging.</h2>
          <p>
            AI disruption, regulatory expectations, ESG transition, education gaps and human stress are no longer separate conversations. OMNeXa helps partners integrate capability, compliance, sustainability and human progress.
          </p>
        </div>
        <div className="pressure-grid">
          {[
            ["AI disruption", "Roles, skills and operating models are being reshaped by intelligent systems."],
            ["Regulatory pressure", "Governance, financial crime and control expectations require stronger accountability."],
            ["ESG transition", "Companies must move from awareness and reporting into practical action."],
            ["Education gap", "Students and professionals need future-ready pathways and proof of capability."],
            ["Human stress", "Teams need resilience, emotional balance and conscious leadership."],
            ["Partnership economy", "Impact now requires collaboration across sectors and ecosystems."]
          ].map(([title, text]) => (
            <div className="pressure-card" key={title}>
              <h3>{title}</h3>
              <p>{text}</p>
            </div>
          ))}
        </div>
      </section>

      <section id="services" className="section-shell services-section">
        <div className="section-heading">
          <p className="eyebrow">Services</p>
          <h2>Six integrated pillars. Multiple ways to engage.</h2>
          <p>
            Each pillar can stand alone. The strongest value comes when they are combined into a practical future-readiness program.
          </p>
        </div>
        <div className="service-grid">
          {services.map((service) => (
            <ServiceCard key={service.slug} service={service} />
          ))}
        </div>
      </section>

      <section id="method" className="section-shell method-section">
        <div className="image-panel">
          <img src="/images/future-city.webp" alt="People and machines collaborating in a sustainable future city" />
        </div>
        <div className="method-copy">
          <p className="eyebrow">How we work</p>
          <h2>Start small. Prove value. Scale what works.</h2>
          <p>
            OMNeXa can plug into existing leadership development, ESG initiatives, compliance remediation, education partnerships, innovation labs or CSR platforms.
          </p>
          <div className="timeline">
            {engagementFormats.map((format, index) => (
              <div className="timeline-item" key={format.name}>
                <span>{String(index + 1).padStart(2, "0")}</span>
                <div>
                  <h3>{format.name}</h3>
                  <small>{format.duration}</small>
                  <p>{format.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section-shell signature-section">
        <div className="section-heading compact">
          <p className="eyebrow">Topmate-style service paths</p>
          <h2>Choose the format that fits your need.</h2>
          <p>Simple entry points for individuals, teams and institutions.</p>
        </div>
        <div className="offer-grid">
          {[
            ["Discovery Call", "30–60 min", "Clarify your requirement and identify the most suitable service path.", "Book now"],
            ["Advisory Sprint", "2–6 weeks", "Focused support for risk, ESG, AI readiness, career pathways or ecosystem mapping.", "Apply for sprint"],
            ["Workshop / Keynote", "Half-day to 1 day", "Future-readiness, AI adoption, ESG activation, well-being or leadership programs.", "Request proposal"],
            ["Fractional Advisory", "3–6 months", "Part-time senior support for compliance, governance, transformation or partnership execution.", "Discuss fit"]
          ].map(([title, duration, text, cta]) => (
            <article className="offer-card" key={title}>
              <span>{duration}</span>
              <h3>{title}</h3>
              <p>{text}</p>
              <a href="#contact" className="text-link">{cta} →</a>
            </article>
          ))}
        </div>
      </section>

      <section id="about" className="section-shell about-section">
        <div className="about-card">
          <div className="about-image">
            <img src="/images/ai-office.webp" alt="AI-enabled advisory and decision support" />
          </div>
          <div>
            <p className="eyebrow">Founder profile</p>
            <h2>About Dhiraj Kumar</h2>
            <p>
              Founder / Advisor of OMNeXa Pte. Ltd., bringing together compliance depth, sustainability thinking, AI-era readiness and human-centered leadership.
            </p>
            <ul className="check-list">
              <li>20+ years in AML/KYC, sanctions, governance and controls.</li>
              <li>Regional and global exposure across APAC and EMEA.</li>
              <li>Certified Sanctions Specialist with practical regulatory execution experience.</li>
              <li>MIT Chief Sustainability Officer Program alumnus with ESG engagement experience.</li>
              <li>Mentor, speaker and ecosystem collaborator for students, professionals and institutions.</li>
            </ul>
          </div>
        </div>
      </section>

      <section id="testimonials" className="section-shell testimonials-section">
        <div className="section-heading">
          <p className="eyebrow">Client feedback</p>
          <h2>What partners and participants value.</h2>
        </div>
        <div className="testimonial-grid">
          {testimonials.map((testimonial) => (
            <blockquote key={testimonial.quote}>
              <p>“{testimonial.quote}”</p>
              <footer>
                <strong>{testimonial.name}</strong>
                <span>{testimonial.role}</span>
              </footer>
            </blockquote>
          ))}
        </div>
      </section>

      <section className="section-shell faq-section">
        <div className="section-heading compact">
          <p className="eyebrow">Before you enquire</p>
          <h2>Frequently asked questions</h2>
        </div>
        <div className="faq-list">
          {faqs.map((faq) => (
            <details key={faq.q}>
              <summary>{faq.q}</summary>
              <p>{faq.a}</p>
            </details>
          ))}
        </div>
      </section>

      <section id="contact" className="section-shell contact-section">
        <ContactForm />
      </section>

      <footer className="site-footer">
        <div>
          <strong>OMNeXa Pte. Ltd.</strong>
          <span>Where Consciousness Meets Intelligence</span>
        </div>
        <div className="footer-links">
          <a href="mailto:dhiraj.kumar@omnexagoc.com">dhiraj.kumar@omnexagoc.com</a>
          <a href={topmateUrl} target="_blank" rel="noreferrer">Topmate</a>
          <a href="#top">Back to top</a>
        </div>
      </footer>
    </main>
  );
}
