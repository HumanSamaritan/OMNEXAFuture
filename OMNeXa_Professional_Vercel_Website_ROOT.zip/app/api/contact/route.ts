import { NextResponse } from "next/server";
import { Resend } from "resend";

function isValidEmail(email: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function escapeHtml(value: string) {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/\'/g, "&#039;");
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { name, email, phone, organisation, serviceLabel, message } = body || {};

    if (!name || !email || !message || !isValidEmail(String(email))) {
      return NextResponse.json(
        { message: "Please provide a valid name, email and message." },
        { status: 400 }
      );
    }

    const apiKey = process.env.RESEND_API_KEY;
    const toEmail = process.env.CONTACT_TO_EMAIL || "dhiraj.kumar@omnexagoc.com";
    const fromEmail = process.env.CONTACT_FROM_EMAIL || "OMNeXa Website <noreply@omnexagoc.com>";

    if (!apiKey) {
      return NextResponse.json(
        { message: "Email service is not configured. Please set RESEND_API_KEY in Vercel." },
        { status: 500 }
      );
    }

    const resend = new Resend(apiKey);
    const safeName = String(name).trim();
    const safeEmail = String(email).trim();
    const safePhone = phone ? String(phone).trim() : "Not provided";
    const safeOrganisation = organisation ? String(organisation).trim() : "Not provided";
    const safeService = serviceLabel ? String(serviceLabel).trim() : "General enquiry";
    const safeMessage = String(message).trim();

    await resend.emails.send({
      from: fromEmail,
      to: toEmail,
      replyTo: safeEmail,
      subject: `OMNeXa website enquiry: ${safeService}`,
      text: `New OMNeXa website enquiry\n\nName: ${safeName}\nEmail: ${safeEmail}\nPhone: ${safePhone}\nOrganisation: ${safeOrganisation}\nService: ${safeService}\n\nMessage:\n${safeMessage}`,
      html: `
        <div style="font-family:Arial,sans-serif;line-height:1.6;color:#111827">
          <h2>New OMNeXa website enquiry</h2>
          <p><strong>Name:</strong> ${escapeHtml(safeName)}</p>
          <p><strong>Email:</strong> ${escapeHtml(safeEmail)}</p>
          <p><strong>Phone:</strong> ${escapeHtml(safePhone)}</p>
          <p><strong>Organisation:</strong> ${escapeHtml(safeOrganisation)}</p>
          <p><strong>Service:</strong> ${escapeHtml(safeService)}</p>
          <p><strong>Message:</strong></p>
          <p>${escapeHtml(safeMessage).replace(/\n/g, "<br />")}</p>
        </div>
      `
    });

    return NextResponse.json({ message: "Enquiry sent." });
  } catch (error) {
    console.error(error);
    return NextResponse.json(
      { message: "Unable to send the enquiry. Please try again or email directly." },
      { status: 500 }
    );
  }
}
