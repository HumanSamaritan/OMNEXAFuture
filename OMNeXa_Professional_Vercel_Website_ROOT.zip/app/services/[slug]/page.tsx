import { notFound } from "next/navigation";
import ContactForm from "@/components/ContactForm";
import { services, topmateUrl } from "@/lib/site-data";

export function generateStaticParams() {
  return services.map((service) => ({ slug: service.slug }));
}

export function generateMetadata({ params }: { params: { slug: string } }) {
  const service = services.find((item) => item.slug === params.slug);
  if (!service) return {};
  return {
    title: `${service.title} | OMNeXa`,
    description: service.short
  };
}

export default function ServicePage({ params }: { params: { slug: string } }) {
  const service = services.find((item) => item.slug === params.slug);
  if (!service) notFound();

  return (
    <main>
      <header className="site-header simple">
        <a href="/" className="brand">
          <img src="/brand/omnexa-mark.webp" alt="OMNeXa logo" />
          <span>
            <strong>OMNeXa</strong>
            <small>Where Consciousness Meets Intelligence</small>
          </span>
        </a>
        <nav>
          <a href="/#services">Services</a>
          <a href="/#about">About</a>
          <a href="/#contact">Contact</a>
        </nav>
        <a className="button header-cta" href="/#contact">Apply / Enquire</a>
      </header>

      <section className="service-detail-hero section-shell">
        <div>
          <p className="eyebrow">OMNeXa service</p>
          <span className="detail-icon">{service.icon}</span>
          <h1>{service.title}</h1>
          <p className="hero-text">{service.short}</p>
          <div className="hero-actions">
            <a className="button primary" href="/#contact">Apply / Enquire</a>
            <a className="button secondary" href={topmateUrl} target="_blank" rel="noreferrer">Book on Topmate</a>
          </div>
        </div>
        <div className="detail-image">
          <img src={service.image} alt={service.title} />
        </div>
      </section>

      <section className="section-shell service-detail-grid">
        <article>
          <h2>Who this is for</h2>
          <p>{service.audience}</p>
        </article>
        <article>
          <h2>Expected outcome</h2>
          <p>{service.outcome}</p>
        </article>
        <article>
          <h2>Available formats</h2>
          <ul>
            {service.formats.map((format) => <li key={format}>{format}</li>)}
          </ul>
        </article>
      </section>

      <section className="section-shell service-includes">
        <div className="section-heading compact">
          <p className="eyebrow">What can be included</p>
          <h2>A practical, implementation-led scope.</h2>
        </div>
        <div className="include-grid">
          {service.includes.map((item) => (
            <div key={item} className="include-card">
              <span>✓</span>
              <p>{item}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="section-shell contact-section">
        <ContactForm initialService={service.slug} />
      </section>
    </main>
  );
}
