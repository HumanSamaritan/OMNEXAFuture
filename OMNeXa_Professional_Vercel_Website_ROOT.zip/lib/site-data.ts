export const topmateUrl = process.env.NEXT_PUBLIC_TOPMATE_URL || "https://topmate.io/dhiraj_kumar007";

export const navItems = [
  { label: "Services", href: "#services" },
  { label: "How it works", href: "#method" },
  { label: "About", href: "#about" },
  { label: "Testimonials", href: "#testimonials" },
  { label: "Contact", href: "#contact" }
];

export type Service = {
  slug: string;
  icon: string;
  title: string;
  short: string;
  audience: string;
  outcome: string;
  formats: string[];
  includes: string[];
  image: string;
};

export const services: Service[] = [
  {
    slug: "career-education-pathways",
    icon: "🎓",
    title: "Career & Education Pathways",
    short: "Future-ready guidance for students, parents and professionals choosing their next path.",
    audience: "Students, parents, schools, universities, working professionals and EdTech partners.",
    outcome: "Clarity on direction, skill-building priorities and a credible roadmap for education or career transition.",
    formats: ["1:1 mentoring", "Parent-student advisory", "School workshops", "Career transition sessions"],
    includes: [
      "Student career counselling and global higher-education pathway discussion",
      "AI-era future-skills planning and proof-of-work guidance",
      "Professional transition mapping and confidence-building conversations",
      "Parent-student decision support for education and career choices"
    ],
    image: "/images/learning-hub.webp"
  },
  {
    slug: "motivational-growth-leadership",
    icon: "⚡",
    title: "Motivational Growth & Leadership",
    short: "Talks and workshops that convert uncertainty into resilience, discipline and action.",
    audience: "Schools, universities, HR teams, employee groups, founders and professional communities.",
    outcome: "A stronger growth mindset, better communication, more confidence and renewed personal purpose.",
    formats: ["Keynote", "Workshop", "Mentoring circle", "Leadership session"],
    includes: [
      "Resilience, self-belief, adaptability and discipline programs",
      "Purpose-led growth and communication sessions",
      "Story-led sessions for students, professionals and teams",
      "Practical reflection tools and action commitments"
    ],
    image: "/images/future-city.webp"
  },
  {
    slug: "risk-compliance-advisory",
    icon: "🛡️",
    title: "Risk, Governance & Financial Crime Advisory",
    short: "Senior fractional advisory for AML/KYC, sanctions, controls and regulatory readiness.",
    audience: "Banks, fintechs, regulated firms, growth-stage companies and compliance teams.",
    outcome: "Clearer governance, stronger controls, better remediation discipline and practical regulatory readiness.",
    formats: ["Advisory sprint", "Fractional advisory", "Gap review", "Remediation support"],
    includes: [
      "AML/KYC/sanctions operating-model and governance review",
      "Screening, alert governance, escalation and risk-based control design",
      "Regulatory exam, audit response and remediation roadmap support",
      "Policy, procedure, control and management-reporting enhancement"
    ],
    image: "/images/ai-office.webp"
  },
  {
    slug: "sustainability-esg-transformation",
    icon: "🌱",
    title: "Sustainability & ESG Transformation",
    short: "Practical ESG activation that moves teams from awareness to measurable action.",
    audience: "Corporates, HR teams, ESG leaders, education partners, foundations and community programs.",
    outcome: "Engaged employees, credible narratives, simple KPIs and visible sustainability behavior change.",
    formats: ["ESG workshop", "Employee activation", "Green champion model", "Impact narrative"],
    includes: [
      "ESG alignment translated into practical business and employee actions",
      "Green-champion programs, campaigns and internal event design",
      "Simple KPIs for engagement, behavior shifts and community impact",
      "Sustainability narratives connecting business action to social value"
    ],
    image: "/images/future-city.webp"
  },
  {
    slug: "ai-robotics-responsible-innovation",
    icon: "🤖",
    title: "AI, Robotics & Responsible Innovation",
    short: "Responsible AI readiness, technology-for-good pilots and ecosystem partnership design.",
    audience: "Corporates, technology companies, robotics partners, education platforms and innovation teams.",
    outcome: "A practical AI adoption narrative rooted in ethics, governance, human value and measurable use cases.",
    formats: ["AI awareness session", "Use-case sprint", "Pilot framing", "Ecosystem partnership"],
    includes: [
      "Responsible AI readiness and workforce-awareness sessions",
      "Use-case framing for education, sustainability, health and inclusion",
      "Pilot design, stakeholder mapping and partnership narratives",
      "Governance thinking for human-centered AI adoption"
    ],
    image: "/images/ai-office.webp"
  },
  {
    slug: "wellbeing-conscious-leadership",
    icon: "🧘",
    title: "Well-being & Conscious Leadership",
    short: "Emotional balance, self-care, reflection and values-led performance for the AI era.",
    audience: "Students, professionals, employee groups, leaders and organizations under transition pressure.",
    outcome: "Improved calmness, clarity, resilience, empathy and sustainable performance habits.",
    formats: ["Well-being session", "Leadership circle", "Reflection workshop", "Mentoring conversation"],
    includes: [
      "Emotional well-being and resilience sessions",
      "Self-care, reflection and purpose-driven growth workshops",
      "Conscious leadership programs linking ethics, empathy and decisions",
      "Workplace well-being advisory linked to engagement and morale"
    ],
    image: "/images/wellbeing.webp"
  }
];

export const engagementFormats = [
  {
    name: "Inspire",
    duration: "45–90 minutes",
    description: "Keynotes, panels and leadership talks to open minds and create urgency."
  },
  {
    name: "Equip",
    duration: "Half-day to 1 day",
    description: "Capability-building workshops and mentoring sessions with practical exercises."
  },
  {
    name: "Advise",
    duration: "2–6 weeks",
    description: "Focused advisory sprint for risk, ESG, AI readiness, education or well-being priorities."
  },
  {
    name: "Build",
    duration: "4–12 weeks",
    description: "Pilot design, ecosystem mapping and operating-roadmap creation."
  },
  {
    name: "Scale",
    duration: "3–6 months",
    description: "Repeatable programs, dashboards, partner alignment and leadership reporting."
  }
];

export const testimonials = [
  {
    quote: "Clear career guidance helped us map aspiration to a practical path. The discussion was calm, structured and focused on what the student can actually do next.",
    name: "Parent of student",
    role: "Career & education guidance"
  },
  {
    quote: "The future-readiness discussion connected AI, skills and purpose in a way our team could understand and act on.",
    name: "Corporate participant",
    role: "AI and leadership workshop"
  },
  {
    quote: "The advisory lens was practical and implementation-oriented, especially around controls, governance and regulatory expectations.",
    name: "Financial services stakeholder",
    role: "Risk and compliance advisory"
  },
  {
    quote: "The sustainability conversation moved beyond slogans into simple actions, engagement and measurable behavior change.",
    name: "Program collaborator",
    role: "ESG and employee activation"
  }
];

export const faqs = [
  {
    q: "What is the best first step?",
    a: "Start with a 30–60 minute discovery conversation. OMNeXa will identify the priority area, target audience and most suitable format."
  },
  {
    q: "Can services be customized?",
    a: "Yes. OMNeXa can support a one-off talk, a structured workshop, a fractional advisory sprint or an integrated program."
  },
  {
    q: "Who is OMNeXa best suited for?",
    a: "Schools, universities, corporates, regulated firms, fintechs, technology companies, foundations and ecosystem partners working on future readiness."
  },
  {
    q: "Does OMNeXa replace internal teams?",
    a: "No. OMNeXa is designed to plug into existing programs and help teams integrate compliance, sustainability, AI adoption, education and human progress."
  }
];
